"""Sensor entities for the Aeroblip integration.

Seven sensors surface the coordinator's three data buckets (overhead,
board, alerts) as HA state. All are defensive against the pre-first-frame
``{}`` snapshot and against any individual field being ``None`` - this
integration is fed live, occasionally messy, third-party flight data.
"""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

import homeassistant.util.dt as dt_util
from homeassistant.components.sensor import (
    SensorEntity,
    SensorEntityDescription,
    SensorStateClass,
)
from homeassistant.const import EntityCategory
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from . import AeroblipConfigEntry
from .coordinator import AeroblipCoordinator
from .entity import AeroblipEntity


def _parse_board_time(value: str | None) -> datetime | None:
    """Parse a board row's ISO timestamp, localising naive values.

    The Aeroblip server emits the airport's local time and does not
    guarantee a UTC offset is present, so a naive result is assumed to
    already be in HA's configured local time zone.
    """
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt_util.DEFAULT_TIME_ZONE)
    return parsed


def _effective_board_time(row: dict[str, Any]) -> datetime | None:
    """Return a board row's best-known time: estimated, falling back to scheduled."""
    return _parse_board_time(row.get("estimated")) or _parse_board_time(
        row.get("scheduled")
    )


def _next_board_row(rows: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Return the soonest upcoming, non-cancelled row with a parseable time.

    Rows are not guaranteed sorted, so this scans the full list. "Soonest
    upcoming" allows a 5-minute grace window behind now to tolerate clock
    skew and rows that just departed/arrived.
    """
    cutoff = dt_util.now() - timedelta(minutes=5)
    best_row: dict[str, Any] | None = None
    best_time: datetime | None = None
    for row in rows:
        status = row.get("status") or ""
        if "cancel" in status.lower():
            continue
        effective = _effective_board_time(row)
        if effective is None or effective < cutoff:
            continue
        if best_time is None or effective < best_time:
            best_time = effective
            best_row = row
    return best_row


def _alert_summary(aircraft: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Reduce raw alert aircraft dicts to the small attrs the frontend needs."""
    return [
        {
            "callsign": a.get("callsign"),
            "registration": a.get("registration"),
            "type": a.get("type"),
            "place": a.get("place"),
            "distance_nm": a.get("distance_nm"),
            "squawk": a.get("squawk"),
        }
        for a in aircraft
    ]


class AeroblipOverheadCountSensor(AeroblipEntity, SensorEntity):
    """Number of aircraft currently inside the overhead radius."""

    _attr_translation_key = "overhead_count"
    _attr_state_class = SensorStateClass.MEASUREMENT

    def __init__(self, coordinator: AeroblipCoordinator) -> None:
        super().__init__(coordinator, "overhead_count")

    @property
    def native_value(self) -> int | None:
        overhead = self.coordinator.data.overhead
        if not overhead or overhead.get("updated") is None:
            return None
        return overhead.get("overhead_count")


class AeroblipNearbyCountSensor(AeroblipEntity, SensorEntity):
    """Number of aircraft currently inside the wider area radius."""

    _attr_translation_key = "nearby_count"
    _attr_state_class = SensorStateClass.MEASUREMENT

    def __init__(self, coordinator: AeroblipCoordinator) -> None:
        super().__init__(coordinator, "nearby_count")

    @property
    def native_value(self) -> int | None:
        overhead = self.coordinator.data.overhead
        if not overhead or overhead.get("updated") is None:
            return None
        return len(overhead.get("aircraft") or [])


class AeroblipNearestAircraftSensor(AeroblipEntity, SensorEntity):
    """Identity and detail of the nearest tracked aircraft."""

    _attr_translation_key = "nearest_aircraft"
    # photo is a large/opaque URL and description churns with every frame;
    # neither is useful in long-term state history.
    _unrecorded_attributes = frozenset({"photo", "description"})

    def __init__(self, coordinator: AeroblipCoordinator) -> None:
        super().__init__(coordinator, "nearest_aircraft")

    def _nearest(self) -> dict[str, Any] | None:
        overhead = self.coordinator.data.overhead
        if not overhead:
            return None
        aircraft = overhead.get("aircraft") or []
        return aircraft[0] if aircraft else None

    @property
    def native_value(self) -> str | None:
        nearest = self._nearest()
        if nearest is None:
            return None
        return nearest.get("callsign") or nearest.get("registration") or nearest.get("hex")

    @property
    def extra_state_attributes(self) -> dict[str, Any] | None:
        nearest = self._nearest()
        if nearest is None:
            return None
        route = nearest.get("route") or {}
        airline = nearest.get("airline") or {}
        info = nearest.get("info") or {}
        return {
            "callsign": nearest.get("callsign"),
            "registration": nearest.get("registration"),
            "aircraft_type": nearest.get("type"),
            "description": nearest.get("description"),
            "altitude_ft": nearest.get("altitude_ft"),
            "ground_speed_kt": nearest.get("ground_speed_kt"),
            "distance_nm": nearest.get("distance_nm"),
            "bearing_from_home": nearest.get("bearing_from_home"),
            "heading_cardinal": nearest.get("heading_cardinal"),
            "phase": nearest.get("phase"),
            "origin": route.get("origin"),
            "origin_name": route.get("origin_name"),
            "destination": route.get("destination"),
            "destination_name": route.get("destination_name"),
            "airline": route.get("airline") or airline.get("airline"),
            "photo": info.get("photo"),
        }


@dataclass(frozen=True, kw_only=True)
class _BoardSensorDescription(SensorEntityDescription):
    """Entity description for a board (arrivals/departures) sensor."""

    rows_fn: Callable[[dict[str, Any]], list[dict[str, Any]]] = lambda board: []


class AeroblipBoardSensor(AeroblipEntity, SensorEntity):
    """Base for the next-arrival / next-departure sensors."""

    entity_description: _BoardSensorDescription

    def __init__(
        self, coordinator: AeroblipCoordinator, description: _BoardSensorDescription
    ) -> None:
        super().__init__(coordinator, description.key)
        self.entity_description = description
        self._attr_translation_key = description.key

    def _next_row(self) -> dict[str, Any] | None:
        board = self.coordinator.data.board
        if not board:
            return None
        rows = self.entity_description.rows_fn(board)
        return _next_board_row(rows)

    @property
    def native_value(self) -> str | None:
        row = self._next_row()
        if row is None:
            return None
        return row.get("flight")

    @property
    def extra_state_attributes(self) -> dict[str, Any] | None:
        row = self._next_row()
        if row is None:
            return None
        return {
            "airline": row.get("airline"),
            "city": row.get("city"),
            "code": row.get("code"),
            "scheduled": row.get("scheduled"),
            "estimated": row.get("estimated"),
            "terminal": row.get("terminal"),
            "gate": row.get("gate"),
            "status": row.get("status"),
            "aircraft_type": row.get("aircraft"),
        }


class AeroblipAlertCountSensor(AeroblipEntity, SensorEntity):
    """Count of active emergency-squawk aircraft."""

    _attr_translation_key = "alert_count"
    _attr_state_class = SensorStateClass.MEASUREMENT

    def __init__(self, coordinator: AeroblipCoordinator) -> None:
        super().__init__(coordinator, "alert_count")

    @property
    def native_value(self) -> int | None:
        alerts = self.coordinator.data.alerts
        if not alerts:
            return None
        return alerts.get("count")

    @property
    def extra_state_attributes(self) -> dict[str, Any] | None:
        alerts = self.coordinator.data.alerts
        if not alerts:
            return None
        return {"alerts": _alert_summary(alerts.get("aircraft") or [])}


class AeroblipProviderSensor(AeroblipEntity, SensorEntity):
    """Diagnostic sensor reporting which ADS-B data provider is in use."""

    _attr_translation_key = "provider"
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, coordinator: AeroblipCoordinator) -> None:
        super().__init__(coordinator, "provider")

    @property
    def native_value(self) -> str | None:
        overhead = self.coordinator.data.overhead
        if not overhead:
            return None
        return overhead.get("provider")

    @property
    def extra_state_attributes(self) -> dict[str, Any] | None:
        overhead = self.coordinator.data.overhead
        updated = overhead.get("updated") if overhead else None
        if updated is None:
            return None
        return {"updated": dt_util.utc_from_timestamp(updated).isoformat()}


async def async_setup_entry(
    hass: HomeAssistant,
    entry: AeroblipConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up Aeroblip sensor entities from a config entry."""
    coordinator = entry.runtime_data
    async_add_entities(
        [
            AeroblipOverheadCountSensor(coordinator),
            AeroblipNearbyCountSensor(coordinator),
            AeroblipNearestAircraftSensor(coordinator),
            AeroblipBoardSensor(
                coordinator,
                _BoardSensorDescription(
                    key="next_arrival",
                    rows_fn=lambda board: board.get("arrivals") or [],
                ),
            ),
            AeroblipBoardSensor(
                coordinator,
                _BoardSensorDescription(
                    key="next_departure",
                    rows_fn=lambda board: board.get("departures") or [],
                ),
            ),
            AeroblipAlertCountSensor(coordinator),
            AeroblipProviderSensor(coordinator),
        ]
    )
