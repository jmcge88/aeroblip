"""Push-mode data coordinator for the Aeroblip integration.

The Aeroblip server streams state over a single long-lived WebSocket
rather than answering polled requests, so this coordinator has no
update_interval - it is fed entirely by AeroblipClient.async_run callbacks
and republishes a fresh AeroblipData snapshot on every frame.
"""
from __future__ import annotations

import dataclasses
import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import CALLBACK_TYPE, HomeAssistant, callback
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator

from .api import AeroblipAuthError, AeroblipClient
from .const import DOMAIN, EVENT_EMERGENCY, EVENT_FLYOVER

_LOGGER = logging.getLogger(__name__)


@dataclass
class AeroblipData:
    """Latest snapshot pushed over the Aeroblip WebSocket."""

    overhead: dict[str, Any] = field(default_factory=dict)
    board: dict[str, Any] = field(default_factory=dict)
    alerts: dict[str, Any] = field(default_factory=dict)
    connected: bool = False


class AeroblipCoordinator(DataUpdateCoordinator[AeroblipData]):
    """Coordinator that fans out Aeroblip WebSocket frames to entities."""

    def __init__(
        self, hass: HomeAssistant, entry: ConfigEntry, client: AeroblipClient
    ) -> None:
        super().__init__(
            hass,
            _LOGGER,
            name=DOMAIN,
            update_interval=None,  # push-mode: data arrives via the WS, not polling
            config_entry=entry,
        )
        self.client = client
        self.data = AeroblipData()
        self._overhead_hexes: set[str] = set()
        self._alert_hexes: set[str] = set()
        # A (re)connect must not replay flyover/emergency events for aircraft
        # that were already overhead/alerting before the reconnect happened.
        self._overhead_primed = False
        self._alerts_primed = False
        self._flyover_listeners: list[Callable[[dict[str, Any]], None]] = []
        self._emergency_listeners: list[Callable[[dict[str, Any]], None]] = []

    def async_start(self) -> None:
        """Start the background task that runs the WebSocket loop."""
        self.config_entry.async_create_background_task(
            self.hass, self._run(), name="aeroblip-ws"
        )

    async def _run(self) -> None:
        """Run the client loop; hand a bad token off to HA's reauth flow."""
        try:
            await self.client.async_run(self._handle_message, self._handle_connection)
        except AeroblipAuthError:
            _LOGGER.info("Aeroblip device token rejected; starting reauth")
            self.config_entry.async_start_reauth(self.hass)

    async def async_shutdown_client(self) -> None:
        """Close the underlying WebSocket so the background task can be cancelled."""
        await self.client.async_stop()

    @callback
    def _handle_connection(self, connected: bool) -> None:
        if connected:
            # Next overhead/alerts frame is a fresh baseline, not new events.
            self._overhead_primed = False
            self._alerts_primed = False
        new_data = dataclasses.replace(self.data, connected=connected)
        self.async_set_updated_data(new_data)

    @callback
    def _handle_message(self, msg_type: str, data: dict[str, Any]) -> None:
        if msg_type == "overhead":
            self._process_overhead(data)
            new_data = dataclasses.replace(self.data, overhead=data)
        elif msg_type == "board":
            new_data = dataclasses.replace(self.data, board=data)
        elif msg_type == "alerts":
            self._process_alerts(data)
            new_data = dataclasses.replace(self.data, alerts=data)
        else:
            _LOGGER.debug("Ignoring unknown Aeroblip message type: %s", msg_type)
            return
        # Always a new object - entities compare references to detect change.
        self.async_set_updated_data(new_data)

    def _process_overhead(self, data: dict[str, Any]) -> None:
        aircraft = data.get("aircraft") or []
        current = {a["hex"] for a in aircraft if a.get("overhead") and a.get("hex")}
        if self._overhead_primed:
            for hex_id in current - self._overhead_hexes:
                match = next((a for a in aircraft if a.get("hex") == hex_id), None)
                if match is not None:
                    self._fire_flyover(match)
        self._overhead_hexes = current
        self._overhead_primed = True

    def _process_alerts(self, data: dict[str, Any]) -> None:
        aircraft = data.get("aircraft") or []
        current = {a["hex"] for a in aircraft if a.get("hex")}
        if self._alerts_primed:
            for hex_id in current - self._alert_hexes:
                match = next((a for a in aircraft if a.get("hex") == hex_id), None)
                if match is not None:
                    self._fire_emergency(match)
        self._alert_hexes = current
        self._alerts_primed = True

    def _fire_flyover(self, aircraft: dict[str, Any]) -> None:
        self.hass.bus.async_fire(
            EVENT_FLYOVER,
            {"aircraft": aircraft, "entry_id": self.config_entry.entry_id},
        )
        for listener in list(self._flyover_listeners):
            listener(aircraft)

    def _fire_emergency(self, aircraft: dict[str, Any]) -> None:
        self.hass.bus.async_fire(
            EVENT_EMERGENCY,
            {"aircraft": aircraft, "entry_id": self.config_entry.entry_id},
        )
        for listener in list(self._emergency_listeners):
            listener(aircraft)

    @callback
    def async_add_flyover_listener(
        self, listener: Callable[[dict[str, Any]], None]
    ) -> CALLBACK_TYPE:
        """Register a callback invoked with the aircraft dict on each new flyover."""
        self._flyover_listeners.append(listener)

        def _remove() -> None:
            if listener in self._flyover_listeners:
                self._flyover_listeners.remove(listener)

        return _remove

    @callback
    def async_add_emergency_listener(
        self, listener: Callable[[dict[str, Any]], None]
    ) -> CALLBACK_TYPE:
        """Register a callback invoked with the aircraft dict on each new emergency."""
        self._emergency_listeners.append(listener)

        def _remove() -> None:
            if listener in self._emergency_listeners:
                self._emergency_listeners.remove(listener)

        return _remove
