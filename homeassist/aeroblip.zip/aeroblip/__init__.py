"""The Aeroblip integration."""
from __future__ import annotations

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_LATITUDE, CONF_LONGITUDE, Platform
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed, ConfigEntryNotReady
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .api import AeroblipAuthError, AeroblipClient, AeroblipConnectionError
from .const import (
    CONF_AIRPORT,
    CONF_AREA_NM,
    CONF_BASE_URL,
    CONF_DEVICE_TOKEN,
    CONF_RADIUS_NM,
)
from .coordinator import AeroblipCoordinator

PLATFORMS: list[Platform] = [
    Platform.BINARY_SENSOR,
    Platform.EVENT,
    Platform.GEO_LOCATION,
    Platform.SENSOR,
]

type AeroblipConfigEntry = ConfigEntry[AeroblipCoordinator]


async def async_setup_entry(hass: HomeAssistant, entry: AeroblipConfigEntry) -> bool:
    """Set up an Aeroblip config entry."""
    # Options win over the original setup data for the fields the options
    # flow can change (radius/area/airport); base_url/token/location are
    # immutable after setup and only ever live in entry.data.
    settings = {**entry.data, **entry.options}

    client = AeroblipClient(
        async_get_clientsession(hass),
        settings[CONF_BASE_URL],
        device_token=settings.get(CONF_DEVICE_TOKEN),
        latitude=settings[CONF_LATITUDE],
        longitude=settings[CONF_LONGITUDE],
        radius_nm=settings[CONF_RADIUS_NM],
        area_nm=settings[CONF_AREA_NM],
        airport=settings[CONF_AIRPORT],
    )

    try:
        await client.async_validate()
    except AeroblipAuthError as err:
        raise ConfigEntryAuthFailed("Aeroblip rejected the device token") from err
    except AeroblipConnectionError as err:
        raise ConfigEntryNotReady("Unable to connect to the Aeroblip server") from err

    coordinator = AeroblipCoordinator(hass, entry, client)
    entry.runtime_data = coordinator
    coordinator.async_start()

    # Options (radius/area/airport) change the WebSocket query params, so a
    # new connection - not just new entity state - is needed on change.
    entry.async_on_unload(entry.add_update_listener(_async_update_listener))

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: AeroblipConfigEntry) -> bool:
    """Unload an Aeroblip config entry."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        # Closing the socket lets the background WS task end promptly instead
        # of waiting for HA's own cancellation of the entry's background task.
        await entry.runtime_data.async_shutdown_client()
    return unload_ok


async def _async_update_listener(hass: HomeAssistant, entry: AeroblipConfigEntry) -> None:
    """Reload the entry when options change so the WS reconnects with new params."""
    await hass.config_entries.async_reload(entry.entry_id)
