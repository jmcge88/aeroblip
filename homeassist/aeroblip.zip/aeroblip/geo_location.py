"""Geolocation platform for the Aeroblip integration.

Every aircraft currently tracked inside the configured area radius is
surfaced as a transient geo_location event so it appears as a moving marker
on the Home Assistant map. Unlike the other platforms, these entities do not
derive from AeroblipEntity - see AeroblipGeolocationEvent for why.
"""
from __future__ import annotations

from typing import Any

from homeassistant.components.geo_location import GeolocationEvent
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import UnitOfLength
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import ATTRIBUTION, DOMAIN, NM_TO_KM
from .coordinator import AeroblipCoordinator


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up Aeroblip geo_location entities from a config entry."""
    coordinator: AeroblipCoordinator = entry.runtime_data
    tracked: dict[str, AeroblipGeolocationEvent] = {}

    @callback
    def _sync() -> None:
        """Reconcile tracked geo_location entities against the latest snapshot."""
        if not coordinator.data.connected:
            # The snapshot is retained across a WebSocket outage, but the
            # positions in it go stale within seconds - a marker 60 km off
            # is worse than no marker, so purge and rebuild on reconnect.
            for hex_id in list(tracked):
                tracked.pop(hex_id).async_remove_self()
            return
        aircraft_list = coordinator.data.overhead.get("aircraft") or []
        current: dict[str, dict[str, Any]] = {}
        for aircraft in aircraft_list:
            hex_id = aircraft.get("hex")
            if (
                hex_id is None
                or aircraft.get("lat") is None
                or aircraft.get("lon") is None
                or aircraft.get("distance_nm") is None
            ):
                # Can't place an aircraft on the map without a position and
                # distance, so it's neither added nor kept alive.
                continue
            current[hex_id] = aircraft

        new_entities: list[AeroblipGeolocationEvent] = []
        for hex_id, aircraft in current.items():
            entity = tracked.get(hex_id)
            if entity is None:
                entity = AeroblipGeolocationEvent(aircraft)
                tracked[hex_id] = entity
                new_entities.append(entity)
            else:
                entity.async_update_from_aircraft(aircraft)
        if new_entities:
            async_add_entities(new_entities)

        for hex_id in list(tracked):
            if hex_id not in current:
                tracked.pop(hex_id).async_remove_self()

    entry.async_on_unload(coordinator.async_add_listener(_sync))
    # Anything already in the snapshot at setup time (e.g. platform reload
    # while aircraft are overhead) should show up immediately, not wait for
    # the next WS frame.
    _sync()


class AeroblipGeolocationEvent(GeolocationEvent):
    """A single aircraft, represented as a transient geo_location marker.

    Deliberately NOT an AeroblipEntity and deliberately has no unique_id:
    geo_location entities are inherently transient (one per aircraft
    currently overhead), and assigning a stable unique_id per airframe hex
    would permanently register every plane that ever flew past in the
    entity registry.
    """

    _attr_should_poll = False
    _attr_source = DOMAIN
    _attr_attribution = ATTRIBUTION
    _attr_icon = "mdi:airplane"
    _attr_unit_of_measurement = UnitOfLength.KILOMETERS

    def __init__(self, aircraft: dict[str, Any]) -> None:
        """Initialize the event entity from the aircraft's first snapshot."""
        self._update_state(aircraft)

    @callback
    def async_update_from_aircraft(self, aircraft: dict[str, Any]) -> None:
        """Refresh position and attributes from a fresh aircraft dict."""
        self._update_state(aircraft)
        self.async_write_ha_state()

    def _update_state(self, aircraft: dict[str, Any]) -> None:
        """Recompute all entity state from an aircraft dict."""
        self._attr_name = (
            aircraft.get("callsign") or aircraft.get("registration") or aircraft["hex"]
        )
        self._attr_latitude = aircraft.get("lat")
        self._attr_longitude = aircraft.get("lon")
        distance_nm = aircraft.get("distance_nm")
        self._attr_distance = (
            round(distance_nm * NM_TO_KM, 1) if distance_nm is not None else None
        )
        route = aircraft.get("route") or {}
        self._attr_extra_state_attributes = {
            "callsign": aircraft.get("callsign"),
            "registration": aircraft.get("registration"),
            "aircraft_type": aircraft.get("type"),
            "altitude_ft": aircraft.get("altitude_ft"),
            "ground_speed_kt": aircraft.get("ground_speed_kt"),
            "track": aircraft.get("track"),
            "heading_cardinal": aircraft.get("heading_cardinal"),
            "phase": aircraft.get("phase"),
            "squawk": aircraft.get("squawk"),
            "overhead": aircraft.get("overhead"),
            "origin": route.get("origin"),
            "destination": route.get("destination"),
            "airline": route.get("airline"),
        }

    @callback
    def async_remove_self(self) -> None:
        """Schedule removal once this aircraft has vanished from the snapshot."""
        if self.hass is not None:
            self.hass.async_create_task(self.async_remove())

    async def async_will_remove_from_hass(self) -> None:
        """Clean up before removal.

        No timers or listeners are registered on the entity itself - the
        coordinator listener driving add/remove lives on the platform's
        _sync callback - so there is nothing extra to release here.
        """
